// Define global variables

var container, scene, camera, renderer, controls;
var grid = document.querySelector('.grid')
var keyboard = new THREEx.KeyboardState();
var clock = new THREE.Clock;
var movingCube;
var movingCube2;
var collideMeshList = [];
var collideMeshList2 = [];
var cubes = [];
var message = document.getElementById("message");

var crash = false;
var crash2 = false;

var score = 0;
var score2 = 0;

var scoreText = document.getElementById("score");
var scoreText2 = document.getElementById("score2");
var id = 0;
var crashId = " ";
var lastCrashId = " ";
var crashId2 = " ";
var lastCrashId2 = " ";

init(); 
animate();



function init() {
	
	
    // Scene
    scene = new THREE.Scene();
    // Camera
    var screenWidth = window.innerWidth;
    var screenHeight = window.innerHeight;
    camera = new THREE.PerspectiveCamera(45, screenWidth / screenHeight, 1, 20000);
    camera.position.set(0, 170, 400);

    // Renderer

	
    if (Detector.webgl) {
        renderer = new THREE.WebGLRenderer({ antialias: true });
    } else {
        renderer = new THREE.CanvasRenderer();
    }
	renderer.setClearColor(0x89cff0);
    renderer.setSize(screenWidth , screenHeight);
    container = document.getElementById("ThreeJS");
    container.appendChild(renderer.domElement);

    controls = new THREE.OrbitControls(camera, renderer.domElement);



/* LIGHT */
  light = new THREE.DirectionalLight(0xf00fff, 1);
  light.position.set(0, 170, 400);
  scene.add(light);
  
    // Join two straight lines

    geometry = new THREE.Geometry();
    geometry.vertices.push(new THREE.Vector3(-300, -15, -3000));
    geometry.vertices.push(new THREE.Vector3(-300, -15, 200));
    var material = new THREE.MeshBasicMaterial({
        color: 0x000000, side: THREE.DoubleSide
    });
    var line1 = new THREE.Line(geometry, material);
    scene.add(line1);
	
	
    geometry = new THREE.Geometry();
    geometry.vertices.push(new THREE.Vector3(300, -15, -3000));
    geometry.vertices.push(new THREE.Vector3(300, -15, 200));
    var line2 = new THREE.Line(geometry, material);
    scene.add(line2);



  let streetGeometry = new THREE.BoxGeometry(610, 12000, 0);
  
  texture= new THREE.TextureLoader().load('highway.jpg');
 let streetMaterial = new THREE.MeshBasicMaterial({
   map:texture
  });
  let street = new THREE.Mesh(streetGeometry, streetMaterial);
  street.rotation.x = Math.PI / 2;
  street.position.z = 2000;
   street.position.y = -20;
  scene.add(street);


  let cloudGeomery = new THREE.PlaneBufferGeometry(9400, 3400);
  texture= new THREE.TextureLoader().load('cloud.jpg');
  
  let cloudMaterial = new THREE.MeshBasicMaterial({
 map:texture
  });
  let cloud = new THREE.Mesh(cloudGeomery,cloudMaterial);
  
  cloud.name = "cloud";

  cloud.position.set( 0, 490, -4000);
  
  scene.add(cloud);

  // grass
  let grassGeomery = new THREE.PlaneBufferGeometry(8000, 9000);
  let grassMaterial = new THREE.MeshBasicMaterial({
    color: 0x008000
  });
  let grass = new THREE.Mesh(grassGeomery,grassMaterial);
  
  grass.name = "Grass";
  grass.rotation.x = -Math.PI/2;
  grass.position.set( 0, -30, -1);
  scene.add(grass);





    // Join the controlled cube

    var cubeGeometry = new THREE.CubeGeometry(30, 30, 30, 5, 5, 5);
	 var cubeGeometry2 = new THREE.CubeGeometry(30, 30, 30, 5, 5, 5);
    var wireMaterial = new THREE.MeshLambertMaterial({
                color: 0xf0fff,
                wireframe: false

    });
	var wireMaterial2 = new THREE.MeshLambertMaterial({
                color: 0xffffff,
                wireframe: false

    });


     movingCube = new THREE.Mesh(cubeGeometry, wireMaterial);
	 movingCube2 = new THREE.Mesh(cubeGeometry2, wireMaterial2);
      
    movingCube.position.set(0, 25, -20);
    scene.add(movingCube);
	 movingCube2.position.set(-40, 25, -20);
    scene.add(movingCube2);



}

  

	



function animate() {
    requestAnimationFrame(animate);
    update();
    renderer.render(scene, camera);

}

function update() {
    var delta = clock.getDelta();
    var moveDistance = 200 * delta;
   

    if (keyboard.pressed("left") ) {
        if (movingCube.position.x > -270)
            movingCube.position.x -= moveDistance;
       
    }
    if (keyboard.pressed("right") ) {
        if (movingCube.position.x < 270)
            movingCube.position.x += moveDistance;
        
    }
    if (keyboard.pressed("up") ) {
        movingCube.position.z -= moveDistance;
    }
    if (keyboard.pressed("down") ) {
        movingCube.position.z += moveDistance;
    }
	
	
	 if (keyboard.pressed("A") ) {
        if (movingCube2.position.x > -270)
            movingCube2.position.x -= moveDistance;
       
    }
    if (keyboard.pressed("D") ) {
        if (movingCube2.position.x < 270)
            movingCube2.position.x += moveDistance;
        
    }
    if (keyboard.pressed("W") ) {
        movingCube2.position.z -= moveDistance;
    }
    if (keyboard.pressed("S") ) {
        movingCube2.position.z += moveDistance;
    }

 
	
	
if  (keyboard.pressed("shift"))
    {
			 noLoop();
    } 
			

    var originPoint = movingCube.position.clone();
	 
     
    for (var vertexIndex = 0; vertexIndex < movingCube.geometry.vertices.length ; vertexIndex++) {
        // Vertex original coordinates
        var localVertex = movingCube.geometry.vertices[vertexIndex].clone();
        // The coordinates of the vertex after transformation

        var globalVertex = localVertex.applyMatrix4(movingCube.matrix);
        var directionVector = globalVertex.sub(movingCube.position);

        var ray = new THREE.Raycaster(originPoint, directionVector.clone().normalize());
        var collisionResults = ray.intersectObjects(collideMeshList);
        if (collisionResults.length > 0 && collisionResults[0].distance < directionVector.length()) {
            crash = true;
            crashId = collisionResults[0].object.name;
            break;
        }
        crash = false;
    }
	
	
	
	var originPoint2 = movingCube2.position.clone();
	
	for (var vertexIndex2 = 0; vertexIndex2 < movingCube2.geometry.vertices.length ; vertexIndex2++) {
        // Vertex original coordinates
        var localVertex2 = movingCube2.geometry.vertices[vertexIndex2].clone();
        // The coordinates of the vertex after transformation

        var globalVertex2 = localVertex2.applyMatrix4(movingCube2.matrix);
        var directionVector2 = globalVertex2.sub(movingCube2.position);

        var ray2 = new THREE.Raycaster(originPoint2, directionVector2.clone().normalize());
        var collisionResults2 = ray2.intersectObjects(collideMeshList2);
        if (collisionResults2.length > 0 && collisionResults2[0].distance < directionVector2.length()) {
            crash2 = true;
            crashId2 = collisionResults2[0].object.name;
            break;
        }
        crash2 = false;
    }

    
	

    if (Math.random() < 0.04 && cubes.length < 30) {
        makeRandomCube();
    }

    for (i = 0; i < cubes.length; i++) {
        if (cubes[i].position.z > camera.position.z) {
            scene.remove(cubes[i]);
            cubes.splice(i, 1);
            collideMeshList.splice(i, 1);
			collideMeshList2.splice(i, 1);
			
        } else {
            cubes[i].position.z += 10;
        }
     
    }
    
	
	
	 if (crash)
	{   
		score=Math.floor(score);
		 scene.remove(movingCube);
		movingCube.material.color.setHex(0Xffffff);
   	
	 
	}
	
	 if(crash2){
		score2=Math.floor(score2);
		scene.remove(movingCube2);
		 
		movingCube2.material.color.setHex(0Xffffff);
     
	   
	 
	}
	
	if (crashId2 == lastCrashId2){
     score2 += 0.05;
    scoreText2.innerText = "player2:" + Math.floor(score2);
	
     
	}  
	if (crashId == lastCrashId){
     
	score += 0.05;
	
    scoreText.innerText = "player1:" + Math.floor(score);
     
	}  
	
	if (crash && crash2 ) {
       
    
		
				 scoreText.innerText = "" ;
			 scoreText2.innerText = "" ;
			message.innerText = "Score:"+ Math.floor(score)+"\n"+"Score2:"+ Math.floor(score2)+"\n"+"PRESS SPACE TO PLAY AGAIN"; 
		   
			if  (keyboard.pressed("space")){
			 window.location.replace("index2.html");
			   }
			noLoop();
             
			
	}
	


}
 
	


// Return a random number between min and max

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
}

// Returns an integer random number between min and max

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}



function makeRandomCube() {
	
	
	
	
	var a = 1 * 50,
        b = 50//+Math.random() *100,
        c = 1 * 50;
    var cubeGeometry = new THREE.CubeGeometry(a,b,c);
    var wired = new THREE.MeshLambertMaterial({
        color: Math.random() * 0xffffff
    });
	

 
  box = new THREE.Mesh(cubeGeometry, wired);

 
    box.position.x = getRandomArbitrary(-250, 250);
    box.position.y = 1 + b / 2;
    box.position.z = getRandomArbitrary(-2200, -4000);
    cubes.push(box);
    
	
  
  

    collideMeshList.push(box);
	collideMeshList2.push(box);
  
  scene.add(box);
  // Body
  
  let truckBodyBase = new THREE.Mesh(new THREE.BoxGeometry(50,40,100));
 
  let truckBack = new THREE.Mesh(new THREE.BoxGeometry(50,15,45));
  // 上底半径 下底半径 高度 圆柱周围的分段面数 沿着圆柱高度的面的行数

  let trunk = new THREE.Mesh(new THREE.BoxGeometry(44,15,40));

  truckBack.position.set(0,12.5,30);


  trunk.position.set(0, 1, 27.5);

  truckBodyBase.updateMatrix();
  
  truckBack.updateMatrix();
  
  trunk.updateMatrix();

  let truckBodyBase_CSG = CSG.fromMesh(truckBodyBase);
 
  let truckBack_CSG = CSG.fromMesh(truckBack);
  
  let trunk_CSG = CSG.fromMesh(trunk);
  let truckBody_CSG = truckBodyBase_CSG
     
      .subtract(truckBack_CSG)
     
      .subtract(trunk_CSG);
  let truckBody = CSG.toMesh(truckBody_CSG, truckBodyBase.matrix);

  
  truckBody.position.set(0,0.5,0);
  truckBody.castShadow = true;
  box.add(truckBody);

  // Wheels
  let wheelGeo = new THREE.CylinderGeometry(10, 10, 5, 24, 24, false);
  let wheelMat = new THREE.MeshLambertMaterial({
    color: 0x171717
  });
  let wheel = new THREE.Mesh(wheelGeo,wheelMat);
  wheel.castShadow = true;
  wheel.rotation.z = -0.5 * Math.PI;

  let wheelPos = [
    {x: -22.5, y: -15, z: 30, name: "BL"},
    {x: 22.5, y: -15, z: 30, name: "BR"}
  ];
  for (let p of wheelPos) {
    var w = wheel.clone();
    w.name = p.name;
    w.position.set(p.x,p.y,p.z);
    box.add(w);
  }
 

  /// V. Lights
  let lightGeo = new THREE.PlaneBufferGeometry(7.5, 10);
 
 
  let backLightMat = new THREE.MeshLambertMaterial({
    color: 0xf65555
  });
  let backLight = new THREE.Mesh(lightGeo,backLightMat);


  let backLeftLight = backLight.clone();
  backLeftLight.position.set(-21.25, 2.5, 50.1);
  box.add(backLeftLight);

  let backRightLight = backLight.clone();
  backRightLight.position.set(21.25, 2.5, 50.1);
  box.add(backRightLight);
}