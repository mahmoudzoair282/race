// Define global variables

var container, scene, camera, renderer, controls;
var grid = document.querySelector('.grid')
var keyboard = new THREEx.KeyboardState();
var clock = new THREE.Clock;
var collideMeshList = [];
var cubes = [];
var message = document.getElementById("message");

var crash = false;
var score = 0;

var scoreText = document.getElementById("score");


init(); 
animate();



function init() {
	
	
    // Scene
    scene = new THREE.Scene();
    // Camera
    var screenWidth = window.innerWidth;
    var screenHeight = window.innerHeight;
    camera = new THREE.PerspectiveCamera(45, screenWidth / screenHeight, 1, 20000);
    camera.position.set(0, 170, 600);

    // Renderer

	
    if (Detector.webgl) {
        renderer = new THREE.WebGLRenderer();
    } else {
        renderer = new THREE.CanvasRenderer();
    }
	
    renderer.setSize(screenWidth , screenHeight);
    container = document.getElementById("ThreeJS");
    container.appendChild(renderer.domElement);

    controls = new THREE.OrbitControls(camera, renderer.domElement);



/* LIGHT */
  light = new THREE.DirectionalLight(0xf00fff, 1);
  light.position.set(0, 170, 400);
  scene.add(light);
  
    // Join two straight lines

    geometry = new THREE.Geometry();
    geometry.vertices.push(new THREE.Vector3(-300, -15, -3000));
    geometry.vertices.push(new THREE.Vector3(-300, -15, 200));
    var material = new THREE.MeshBasicMaterial({
        color: 0x000000, side: THREE.DoubleSide
    });
    var line1 = new THREE.Line(geometry, material);
    scene.add(line1);
	
	
    geometry = new THREE.Geometry();
    geometry.vertices.push(new THREE.Vector3(300, -15, -3000));
    geometry.vertices.push(new THREE.Vector3(300, -15, 200));
    var line2 = new THREE.Line(geometry, material);
    scene.add(line2);



  let streetGeometry = new THREE.BoxGeometry(610, 12000, 0);
  
  texture= new THREE.TextureLoader().load('highway.jpg');
 let streetMaterial = new THREE.MeshBasicMaterial({
   map:texture
  });
  let street = new THREE.Mesh(streetGeometry, streetMaterial);
  street.rotation.x = Math.PI / 2;
  street.position.z = 2000;
   street.position.y = -20;
  scene.add(street);


  let cloudGeomery = new THREE.PlaneBufferGeometry(9400, 3400);
  texture= new THREE.TextureLoader().load('cloud.jpg');
  
  let cloudMaterial = new THREE.MeshBasicMaterial({
 map:texture
  });
  let cloud = new THREE.Mesh(cloudGeomery,cloudMaterial);
  
  cloud.name = "cloud";

  cloud.position.set( 0, 490, -4000);
  
  scene.add(cloud);

  // grass
  let grassGeomery = new THREE.PlaneBufferGeometry(8000, 9000);
  let grassMaterial = new THREE.MeshBasicMaterial({
    color: 0x008000
  });
  let grass = new THREE.Mesh(grassGeomery,grassMaterial);
  
  grass.name = "Grass";
  grass.rotation.x = -Math.PI/2;
  grass.position.set( 0, -30, -1);
  scene.add(grass);



  


    // Join the controlled cube

    var boxgeo = new THREE.BoxGeometry(40, 30, 45);
    var material = new THREE.MeshBasicMaterial({ color: 0xF0320C });
    box3 = new THREE.Mesh(boxgeo, material);
    box3.position.x += 0;
    scene.add(box3);

    //2     body 2
    var boxgeo = new THREE.BoxGeometry(40, 20, 35);
    var material = new THREE.MeshBasicMaterial({ color: 0xF0320C });
    box4 = new THREE.Mesh(boxgeo, material);
    box4.position.y += 30;
    box4.position.x += 0;
    box4.position.z += 20;
    scene.add(box4);

    

    //4     rear bumper
    var boxgeo = new THREE.BoxGeometry(41, 12, 4);
    var material = new THREE.MeshBasicMaterial({ color: 0x4F4D4D });
    box6 = new THREE.Mesh(boxgeo, material);
    box6.position.z += 45;
    box6.position.y -= 10;
    scene.add(box6);
    


    //wheels
//left front
    var geometry = new THREE.SphereGeometry(6.4, 6.4, 6.4);
    var material = new THREE.MeshBasicMaterial({ color: 0x484848 });
    sphere = new THREE.Mesh(geometry, material);
    sphere.position.x += 20;
    sphere.position.z -= 20;
    sphere.position.y -= 15;
    scene.add(sphere);
//right front
    var geometry = new THREE.SphereGeometry(6.4, 6.4, 6.4);
    var material = new THREE.MeshBasicMaterial({ color: 0x484848 });
    sphere2 = new THREE.Mesh(geometry, material);
    sphere2.position.x -= 20;
    sphere2.position.z -= 20;
    sphere2.position.y -= 15;
    scene.add(sphere2);
//right rear
    var geometry = new THREE.SphereGeometry(6.4, 6.4, 6.4);
    var material = new THREE.MeshBasicMaterial({ color: 0x484848 });
    sphere3 = new THREE.Mesh(geometry, material);
    sphere3.position.x += 20;
    sphere3.position.z += 17;
    sphere3.position.y -= 20;
    scene.add(sphere3);
//left rear
    var geometry = new THREE.SphereGeometry(6.4, 6.4, 6.4);
    var material = new THREE.MeshBasicMaterial({ color: 0x484848 });
    sphere4 = new THREE.Mesh(geometry, material);
    sphere4.position.x -= 20;
    sphere4.position.z += 17;
    sphere4.position.y -= 20;
    scene.add(sphere4);

    //windows

    //rear
    var geometry = new THREE.PlaneGeometry(35, 15, 4);
    var material = new THREE.MeshBasicMaterial({ color: 0xB2B2B2});
    plane2 = new THREE.Mesh(geometry, material);
    plane2.position.y += 33;
    plane2.position.z += 55;
    scene.add(plane2);
    
//left
    var geometry = new THREE.PlaneGeometry(35, 15, 4);
    var material = new THREE.MeshBasicMaterial({ color: 0xB2B2B2});
    plane4 = new THREE.Mesh(geometry, material);
    plane4.rotation.y = -0.5 * Math.PI;
    plane4.position.x = -21;
    plane4.position.y = 33;
    plane4.position.z = 18;
    scene.add(plane4);
//right
    var geometry = new THREE.PlaneGeometry(35, 15, 4);
    var material = new THREE.MeshBasicMaterial({ color: 0xB2B2B2 });
    plane5 = new THREE.Mesh(geometry, material);
    plane5.rotation.y = -0.5 * Math.PI;
    plane5.position.x = 21;
    plane5.position.y = 33;
    plane5.position.z = 18;
    scene.add(plane5);

//right
    var geometry = new THREE.SphereGeometry(4, 4, 4);
    var material = new THREE.MeshBasicMaterial({ color: 0xFFFB00 });
    sphere5 = new THREE.Mesh(geometry, material);
    sphere5.position.x += 17;
    sphere5.position.z += 50;
    sphere5.position.y += 8;

    scene.add(sphere5);
//left
    var geometry = new THREE.SphereGeometry(4, 4, 4);
    var material = new THREE.MeshBasicMaterial({ color: 0xFFFB00 });
    sphere6 = new THREE.Mesh(geometry, material);
    sphere6.position.x -= 17;
    sphere6.position.z += 50;
    sphere6.position.y += 8;

    scene.add(sphere6);

    //Plates

//rear
    var geometry = new THREE.PlaneGeometry(20, 8, 4);
    var material = new THREE.MeshBasicMaterial({ color: 0xFFFFFF});
    plane7 = new THREE.Mesh(geometry, material);
    plane7.position.y -= 10;
    plane7.position.z += 52;
    scene.add(plane7);




}

  

	



function animate() {
    requestAnimationFrame(animate);
    update();
    renderer.render(scene, camera);

}

function update() {
    var speed = clock.getDelta();
    var moveDistance = 300 * speed;


    if (keyboard.pressed("left") || keyboard.pressed("A")) {
        if (box3.position.x > -270)
        {
          box3.position.x -= moveDistance;
          box4.position.x -= moveDistance;
          
          box6.position.x -= moveDistance;

          sphere.position.x -= moveDistance;
          sphere2.position.x -= moveDistance;
          sphere3.position.x -= moveDistance;
          sphere4.position.x -= moveDistance;
          sphere5.position.x -= moveDistance;
          sphere6.position.x -= moveDistance;
        


          plane2.position.x -= moveDistance;
          
          plane4.position.x -= moveDistance;
          plane5.position.x -= moveDistance;
          
          plane7.position.x -= moveDistance;
        }
        if (camera.position.x > -150) {
            camera.position.x -= moveDistance * 0.6;
           
        }
    }
    if (keyboard.pressed("right") || keyboard.pressed("D")) {
        if (box3.position.x < 270)
            {
                box3.position.x += moveDistance;
                box4.position.x += moveDistance;
                box6.position.x += moveDistance;

                sphere.position.x += moveDistance;
                sphere2.position.x += moveDistance;
                sphere3.position.x += moveDistance;
                sphere4.position.x += moveDistance;
                sphere5.position.x += moveDistance;
                sphere6.position.x += moveDistance;

                plane2.position.x += moveDistance;
          
                plane4.position.x += moveDistance;
                plane5.position.x += moveDistance;
                plane7.position.x += moveDistance;
            }
        if (camera.position.x < 150) {
            camera.position.x += moveDistance * 0.6;
            
        }
    }
    if (keyboard.pressed("up") || keyboard.pressed("W")) {
        box3.position.z -= moveDistance;
        box4.position.z -= moveDistance;
        box6.position.z -= moveDistance;

        sphere.position.z -= moveDistance;
        sphere2.position.z -= moveDistance;
        sphere3.position.z -= moveDistance;
        sphere4.position.z -= moveDistance;
        sphere5.position.z -= moveDistance;
        sphere6.position.z -= moveDistance;

        plane2.position.z -= moveDistance;
        
        plane4.position.z -= moveDistance;
        plane5.position.z -= moveDistance;
        plane7.position.z -= moveDistance;
        
    }
    if (keyboard.pressed("down") || keyboard.pressed("S")) {
        box3.position.z += moveDistance;
        box4.position.z += moveDistance;
        
        box6.position.z += moveDistance;

        sphere.position.z += moveDistance;
        sphere2.position.z += moveDistance;
        sphere3.position.z += moveDistance;
        sphere4.position.z += moveDistance;
        sphere5.position.z += moveDistance;
        sphere6.position.z += moveDistance;

        plane2.position.z += moveDistance;
        
        plane4.position.z += moveDistance;
        plane5.position.z += moveDistance;
        plane7.position.z += moveDistance;
    }

  
if  (keyboard.pressed("shift")){
			 noLoop();
			   } 
			

    var originPoint = box3.position.clone();

    for (var vertexIndex = 0; vertexIndex < box3.geometry.vertices.length; vertexIndex++) {
        // Vertex original coordinates
        var localVertex = box3.geometry.vertices[vertexIndex].clone();
        // The coordinates of the vertex after transformation

        var globalVertex = localVertex.applyMatrix4(box3.matrix);
        var directionVector = globalVertex.sub(box3.position);

        var ray = new THREE.Raycaster(originPoint, directionVector.clone().normalize());
        var collisionResults = ray.intersectObjects(collideMeshList);
        if (collisionResults.length > 0 && collisionResults[0].distance < directionVector.length()) {
            crash = true;
          
            break;
        }
        crash = false;
    }

    if (crash) {
			
			 scoreText.innerText = "" ;
			message.innerText = "Score:"+ Math.floor(score)+"\n"+"PRESS SPACE TO PLAY AGAIN"; 
		   
			if  (keyboard.pressed("space")){
			 window.location.replace("index.html");
			   }
			noLoop();
             
			  			
			

	

        
    } 
	
	


    if (Math.random() < 0.04 && cubes.length < 30) {
        makeRandomCube();
    }

    for (i = 0; i < cubes.length; i++) {
        if (cubes[i].position.z > camera.position.z) {
            scene.remove(cubes[i]);
            cubes.splice(i, 1);
            collideMeshList.splice(i, 1);
        } else {
            cubes[i].position.z += 10;
        }
   
    }

    score += 0.05;
    scoreText.innerText = "Score:" + Math.floor(score);

}
 
	


// Return a random number between min and max

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
}

// Returns an integer random number between min and max

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}



function makeRandomCube() {
	
	
	
	
	var a = 1 * 50,
        b = 50//+Math.random() *100,
        c = 1 * 50;
    var cubeGeometry = new THREE.CubeGeometry(a,b,c);
    var wired = new THREE.MeshLambertMaterial({color: Math.random() * 0xffffff});
	


  box = new THREE.Mesh(cubeGeometry, wired);

    box.position.x = getRandomArbitrary(-250, 250);
    box.position.y = 1 + b / 2;
    box.position.z = getRandomArbitrary(-2200, -4000);
    cubes.push(box);
    
	
    collideMeshList.push(box);
  
  scene.add(box);
  // Body
  
  let truckBodyBase = new THREE.Mesh(new THREE.BoxGeometry(50,40,100));
 
  let truckBack = new THREE.Mesh(new THREE.BoxGeometry(50,15,45));
 

  let trunk = new THREE.Mesh(new THREE.BoxGeometry(44,15,40));

  truckBack.position.set(0,12.5,30);


  trunk.position.set(0, 1, 27.5);

  truckBodyBase.updateMatrix();
  
  truckBack.updateMatrix();
  
  trunk.updateMatrix();

  let truckBodyBase_CSG = CSG.fromMesh(truckBodyBase);
 
  let truckBack_CSG = CSG.fromMesh(truckBack);
  
  let trunk_CSG = CSG.fromMesh(trunk);
  let truckBody_CSG = truckBodyBase_CSG
     
      .subtract(truckBack_CSG)
     
      .subtract(trunk_CSG);
  let truckBody = CSG.toMesh(truckBody_CSG, truckBodyBase.matrix);

  
  truckBody.position.set(0,0.5,0);

  box.add(truckBody);



  // Lights
  let lightGeo = new THREE.PlaneBufferGeometry(7.5, 10);
 
 
  let backLightMat = new THREE.MeshLambertMaterial({
    color: 0xf65555
  });
  let backLight = new THREE.Mesh(lightGeo,backLightMat);


  let backLeftLight = backLight.clone();
  backLeftLight.position.set(-21.25, 2.5, 50.1);
  box.add(backLeftLight);

  let backRightLight = backLight.clone();
  backRightLight.position.set(21.25, 2.5, 50.1);
  box.add(backRightLight);
}